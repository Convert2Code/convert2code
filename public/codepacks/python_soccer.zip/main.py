# This program uses the pygame module to create a very simple game.
# The framework of this game can be modified or improved upon to
# better the game or make something completely different. Before 
# running this script you must first install the pygame package
# with the following command:
# pip install pygame
# If this does not work, you need to first install PIP or install
# pygame another way. The game below involves a soccerball moving
# left and right to avoid defenders. When the ball goes out of
# bounds or hits a defender the game resets.

# Author: Gabriel Stewart


# Import the necessary modules.
import pygame
import random
import time

# Initiate the pygame module.
pygame.init()

# Define the display size.
display_width = 800
display_height = 600

# Define the ball sizes.
ball_width = 50
ball_height = 50

# Create the initial colors.
black = (0, 0, 0)
white = (255, 255, 255)
green = (25, 111, 12)

# Load the image of the soccer ball.
ball = pygame.image.load('SoccerBall.png')
defender_image = pygame.image.load('Defender.jpg')

# Create the display.
gameDisplay = pygame.display.set_mode((display_width, display_height))

# Title the game.
pygame.display.set_caption('Dribble')

# Set the clock.
clock = pygame.time.Clock()


# This function sets the sidelines.
def display_lines():
    line_width = 10
    pygame.draw.rect(gameDisplay, white, [50, 0, line_width, display_height])
    pygame.draw.rect(gameDisplay, white, [740, 0, line_width, display_height])


# This function creates the the text surface.
def text_objects(text, font):
    textSurface = font.render(text, True, black)
    return textSurface, textSurface.get_rect()


# This function displays a message using the text surface.
def message_display(text):
    largeText = pygame.font.Font('freesansbold.ttf', 45)
    TextSurf, TextRect = text_objects(text, largeText)
    TextRect.center = ((display_width/2),(display_height/2))
    gameDisplay.blit(TextSurf, TextRect)
    
    pygame.display.update()

    time.sleep(2)

# This function displays the score.
def display_score(count):
    font = pygame.font.SysFont(None, 25)
    text = font.render("Score: "+ str(count), True, black)
    gameDisplay.blit(text,(360,5))


# This function occurs when the ball crosses the sideline.
def out():
    message_display("You Dribbled Out")



# This function occurs when the ball is stolen.
def steal():
    message_display("The Defender Stole the Ball")


# Create the defender class and a registry within it.
class defender:
    registry = []

    # Create an instance of the defender and add it to the registry.
    def __init__ (self,):
        self.registry.append(self)
        self.x = random.randrange(30, 670)
        self.y = - 600
        self.width = 100
        self.height = 100
        self.speed = 7
        self.image = defender_image

    # Create a method for to display an instance of the defender.
    def display(self):
      gameDisplay.blit(self.image, (self.x, self.y))


def display_ball(x,y):
    gameDisplay.blit(ball, (x, y))


# This function is where the majority is run and maintains the flow.
def game_loop():

    # Set the initial constants for the ball.
    x = display_width * .45
    y = display_height * .85
    x_change = 0

    # The initial count is set to zero.
    count = 0

    # Create the first instance of the defeneder class.
    defender_1 = defender()

    # This loop will continue infinitely unless broken by one of the return
    # statements. This is a bad practice but I was running out of time.
    while True:

        # For every event in the game do the fowing.
        for event in pygame.event.get():

            # Print the event in the terminal.
            print(event)

            # If the event was hitting the red "X." return False.
            if event.type == pygame.QUIT:
                return False
            
            # If it was a key pressing down, complete the following
            if event.type == pygame.KEYDOWN:
                
                # If it was a left key, set x_change to -5.
                if event.key == pygame.K_LEFT:
                    x_change = -5

                # If it was a right key, set x_change to 5.
                if event.key == pygame.K_RIGHT:
                    x_change = 5

            # If it was a key picking up, set the x_change to zero
            if event.type == pygame.KEYUP:
                if ((event.key == pygame.K_LEFT and x_change == -5) or 
                    (event.key == pygame.K_RIGHT and x_change == 5)):
                    x_change = 0
        
        # Change the location of the ball based on the x_change
        x += x_change
        
        # Set the background color.
        gameDisplay.fill(green)
        
        # Create the sidelines.
        display_lines()

        # Show the score based on the count.
        display_score(count)

        # Display the ball at its current location.
        display_ball(x, y)

        # If the ball crosses the sidelines, run the out function, return True,
        # and remove all instances of the defender from the registry.
        if x > (display_width - ball_width) or x < 0:
            out()
            del defender.registry[:]
            return True 

        # For each defender in the registry, complete the following.
        for d in defender.registry:

            # Change the location of the defender using the speed.
            d.y += d.speed

            # Display the current defender.
            d.display()

            # If the defender moves off of the screen, create new defender locations and
            # change the speed of the defender.
            if d.y > display_height:
                d.y = 0 - display_height
                d.x = random.randrange(30, 670)
                d.speed += 1
                count += 1

            # If the ball and defender crossover on the x and y axis run the steal function,
            # return True, and remove all instances of defender from the registry.
            if y < d.y + d.height and y + ball_height > d.y:

                if ((x > d.x and x < d.x + d.width) or 
                    (x + ball_width > d.x and x + ball_width < d.x + d.width)):

                    steal()
                    del defender.registry[:]
                    return True

        # Update the display.
        pygame.display.update()
        clock.tick(60)


# Set the play variable equal to True.
play = True

# Continue running the play function until False is returned.
while play:
    play = game_loop() 

# End the game and close the window.
pygame.quit()
quit()
